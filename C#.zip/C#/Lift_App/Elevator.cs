using System;

namespace Lift
{
    // Определение собственного делегата
    public delegate void TechnicalStop(object sender, EventArgs e);

    // Класс "Лифт"
    public class Elevator
    {
        public event TechnicalStop? TechnicalStop;

        private int currentFloor = 1; // Начальный этаж

        public void Move()
        {
            Random random = new Random();
            int targetFloor = random.Next(1, 9); // Генерируем случайный этаж от 1 до 8
            Console.WriteLine($"Лифт движется к этажу: {targetFloor}");

            while (currentFloor != targetFloor)
            {
                if (currentFloor < targetFloor)
                {
                    currentFloor++;
                }
                else
                {
                    currentFloor--;
                }

                Console.WriteLine($"Лифт на этаже: {currentFloor}");

                if (currentFloor == 3)
                {
                    OnTechnicalStop();
                    // Подождаем, пока пассажир нажмет кнопку "Едем" для продолжения
                    Console.ReadLine();
                }
            }

            Console.WriteLine("Лифт достиг целевого этажа.");
        }

        protected virtual void OnTechnicalStop()
        {
            TechnicalStop?.Invoke(this, EventArgs.Empty);
        }
    }
}
