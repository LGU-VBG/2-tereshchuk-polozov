using System;

namespace Lift
{
    class Program
    {
        static void Main(string[] args)
        {
            Elevator elevator = new Elevator();
            Passenger passenger = new Passenger();

            elevator.TechnicalStop += passenger.OnTechnicalStop;

            elevator.Move();
        }
    }
}
