using System;

namespace Lift
{
    // Класс "Пассажир"
    public class Passenger
    {
        public void OnTechnicalStop(object sender, EventArgs e)
        {
            Console.WriteLine("Техническая остановка! Пассажир нажимает 'Едем' для продолжения...");
        }
    }
}
